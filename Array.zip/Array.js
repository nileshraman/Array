// let age=[12,55,69,48,36,77,25,21,66]


// alert(age.shift());
// alert(age.unshift(14));

// age.push(10,20,30,40);
// age.pop();

// for(let i=0;i<age.length;i++){
//     alert(age[i]);
// }

// for (let ag of age ){
//     alert(ag);
// }


// for (let key in age){
//     console.log (age[key]);
// }


// console.log(age.length);
// console.log(age);

// let matrix=[
//     [1,2,3],
//     [4,5,6],
//     [7,8,9]
// ];

// console.log(matrix[0][2]);


// let arr=[1,5,9];
// console.log(String(arr));


// console.log([]+1);
// console.log([1]+1);
// console.log([1,2]+6);

// console.log([]==[]);
// console.log([0],[0]);

// console.log(0==[]);
// console.log('0'==[]);


// let arr=['j','l','o'];
// arr.splice(1,1,'g')
// arr.splice(0,1,'g');
// arr.splice(0,0,'g');



// let arr=[1,5,6,9];
// arr.splice(-1,0,4)
// console.log(arr);


// let arr=[1,2,false,2];
// console.log(arr.indexOf(null));
// console.log(arr.lastIndexOf(2));

// // For ascending order
// function compare(a,b){
//     return a-b;
// }


// // For descending order 

// function compare(a,b){
//     return b-a ;
// }

// let arr=[1,2,5,9,4,66,99,45];
// arr.sort(compare);

// let arr=[1,2,5,9,4,66,99,45];

// arr.reverse()